package submission

// This file is the only file you need to modify.
// Add your STM implementation here.

import "C"
import (
	"assign2/utils"
	"assign2/wg"
	"context"
	"fmt"
	"io"
	"net"
	"os"
	"time"
)

type StmInterface struct {
	wg *wg.WaitGroup
	// Add your own fields here.
}

func (s *StmInterface) Init(ctx context.Context, wg *wg.WaitGroup) {
	s.wg = wg
}

func (s *StmInterface) Shutdown(ctx context.Context) {
	s.wg.Wait()
}

func (s *StmInterface) Accept(ctx context.Context, conn net.Conn) {
	s.wg.Add(2)

	go func() {
		defer s.wg.Done()
		<-ctx.Done()
		conn.Close()
	}()

	// This goroutine handles the connection.
	go func() {
		defer s.wg.Done()
		handleConn(conn)
	}()
}

func handleConn(conn net.Conn) {
	defer conn.Close()
	for {
		input, err := utils.ReadInput(conn)
		if err != nil {
			if err != io.EOF {
				_, _ = fmt.Fprintf(os.Stderr, "Error reading input: %v\n", err)
			}
			return
		}

		switch input.CommandType {
		case utils.START:
			// TODO: implement START
		case utils.COMMIT:
			// TODO: implement COMMIT
		case utils.READ:
			// TODO: implement READ
		case utils.WRITE:
			// TODO: implement WRITE
		default:
			fmt.Fprintf(os.Stderr, "Got command: %c %v, Address: %v, value: %v\n",
				input.CommandType, input.TransactionId, input.Address, input.Value)

			// Remember to take the timestamp at the appropriate time!
			outputTime := GetCurrentTimestamp()

			// Example: calling PrintOutput — check the parameter names in io.go.
			utils.PrintOutput(input.TransactionId, []utils.StmCommand{input}, outputTime)
		}
	}
}

func GetCurrentTimestamp() int64 {
	return time.Now().UnixNano()
}
